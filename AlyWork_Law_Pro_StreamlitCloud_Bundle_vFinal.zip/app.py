# app.py

# AlyWork Law Pro — Streamlit Cloud ready single-file app (Arabic-first)
# [الكود الكامل من textdoc الذي يحتوي على كل الصفحات والوظائف سيتم إدراجه]
