# ⚖️ AlyWork Law Pro — المنصة الذكية لقانون العمل الأردني

تطبيق Streamlit قانوني ذكي يساعد العمال، أصحاب العمل، المفتشين، والباحثين على فهم وتطبيق قانون العمل الأردني من خلال واجهة تفاعلية مدعومة بالذكاء الاصطناعي.

## 📦 المكونات
- app.py: التطبيق الرئيسي.
- mini_ai_smart.py: المحلل القانوني الذكي.
- requirements.txt: المكتبات المطلوبة.

## 🚀 التشغيل محليًا
pip install -r requirements.txt
streamlit run app.py

## 🌐 النشر على Streamlit Cloud
1. ارفع الملفات إلى GitHub.
2. اربط حسابك بـ Streamlit Cloud.
3. اختر app.py كملف تشغيل رئيسي.
4. اضغط “Deploy”.
